#!/usr/bin/env python3
"""
NAPX-Pro YARA Scanner
Scans PCAP payload bytes against YARA rule sets and outputs structured results.
"""

import json
import sys
import os
import hashlib
from datetime import datetime, timezone

def main():
    if len(sys.argv) < 4:
        print("Usage: scan.py <pcap_path> <rules_dir> <output_json>")
        sys.exit(1)

    pcap_path = sys.argv[1]
    rules_dir = sys.argv[2]
    output_path = sys.argv[3]

    try:
        import yara
    except ImportError:
        print("[!] yara-python not installed, writing empty results")
        _write_empty(output_path, pcap_path)
        return

    # Compile all .yar/.yara files in the rules directory
    rule_files = {}
    if os.path.isdir(rules_dir):
        for f in os.listdir(rules_dir):
            if f.endswith(('.yar', '.yara')):
                namespace = os.path.splitext(f)[0]
                rule_files[namespace] = os.path.join(rules_dir, f)

    if not rule_files:
        print("[!] No YARA rules found, writing empty results")
        _write_empty(output_path, pcap_path)
        return

    print(f"[+] Compiled {len(rule_files)} rule file(s)")
    rules = yara.compile(filepaths=rule_files)

    # Read PCAP as raw bytes and scan
    with open(pcap_path, 'rb') as f:
        pcap_data = f.read()

    file_hash = hashlib.sha256(pcap_data).hexdigest()
    matches = rules.match(data=pcap_data)

    results = {
        "scan_time": datetime.now(timezone.utc).isoformat(),
        "pcap": os.path.basename(pcap_path),
        "pcap_sha256": file_hash,
        "pcap_size_bytes": len(pcap_data),
        "rules_loaded": len(rule_files),
        "matches": []
    }

    for match in matches:
        results["matches"].append({
            "rule": match.rule,
            "namespace": match.namespace,
            "tags": match.tags,
            "meta": {k: str(v) for k, v in match.meta.items()} if match.meta else {},
            "strings": [
                {
                    "offset": s[0],
                    "identifier": s[1],
                    "data_hex": s[2].hex()[:200]  # Truncate large matches
                }
                for s in match.strings
            ][:50]  # Cap at 50 string matches per rule
        })

    print(f"[+] {len(results['matches'])} YARA match(es)")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)


def _write_empty(output_path, pcap_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump({
            "scan_time": datetime.now(timezone.utc).isoformat(),
            "pcap": os.path.basename(pcap_path),
            "rules_loaded": 0,
            "matches": [],
            "note": "No YARA rules found in rules directory"
        }, f, indent=2)


if __name__ == "__main__":
    main()
