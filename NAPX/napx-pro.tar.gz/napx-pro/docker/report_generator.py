#!/usr/bin/env python3
"""
NAPX-Pro Report Generator
Reads Suricata eve.json, Zeek logs, YARA results, IOCs → self-contained HTML report.
"""

import json
import os
import glob
from datetime import datetime, timezone
from collections import Counter

OUTPUT_DIR = "/output"
LOG_DIR = "/logs"


def load_json_safe(path):
    """Load a JSON file, returning empty dict/list on failure."""
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def load_eve_json(path):
    """Load Suricata eve.json (newline-delimited JSON)."""
    events = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except FileNotFoundError:
        pass
    return events


def parse_zeek_log(path):
    """Parse a Zeek TSV log file into list of dicts."""
    rows = []
    headers = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#fields'):
                    headers = line.split('\t')[1:]
                elif line.startswith('#'):
                    continue
                elif headers:
                    vals = line.split('\t')
                    rows.append(dict(zip(headers, vals)))
    except FileNotFoundError:
        pass
    return rows


def analyse_suricata(events):
    """Extract alert statistics from Suricata events."""
    alerts = [e for e in events if e.get('event_type') == 'alert']
    severity_counts = Counter(a.get('alert', {}).get('severity', 0) for a in alerts)
    category_counts = Counter(a.get('alert', {}).get('category', 'unknown') for a in alerts)
    signature_counts = Counter(a.get('alert', {}).get('signature', 'unknown') for a in alerts)

    top_signatures = signature_counts.most_common(20)

    src_ips = Counter(a.get('src_ip', 'unknown') for a in alerts)
    dst_ips = Counter(a.get('dest_ip', 'unknown') for a in alerts)

    return {
        "total_events": len(events),
        "total_alerts": len(alerts),
        "severity": dict(severity_counts),
        "categories": dict(category_counts.most_common(15)),
        "top_signatures": top_signatures,
        "top_src_ips": src_ips.most_common(10),
        "top_dst_ips": dst_ips.most_common(10),
    }


def analyse_zeek(log_dir):
    """Parse key Zeek logs for summary stats."""
    conn_log = parse_zeek_log(os.path.join(log_dir, "conn.log"))
    dns_log = parse_zeek_log(os.path.join(log_dir, "dns.log"))
    http_log = parse_zeek_log(os.path.join(log_dir, "http.log"))
    ssl_log = parse_zeek_log(os.path.join(log_dir, "ssl.log"))
    files_log = parse_zeek_log(os.path.join(log_dir, "files.log"))

    protocols = Counter(c.get('proto', 'unknown') for c in conn_log)
    services = Counter(c.get('service', '-') for c in conn_log if c.get('service', '-') != '-')
    dns_queries = Counter(d.get('query', '') for d in dns_log if d.get('query'))
    http_hosts = Counter(h.get('host', '') for h in http_log if h.get('host'))

    return {
        "connections": len(conn_log),
        "dns_queries_total": len(dns_log),
        "http_requests": len(http_log),
        "ssl_sessions": len(ssl_log),
        "files_seen": len(files_log),
        "protocols": dict(protocols),
        "services": dict(services.most_common(10)),
        "top_dns": dns_queries.most_common(15),
        "top_http_hosts": http_hosts.most_common(10),
    }


def generate_html(suricata_stats, zeek_stats, yara_results, iocs, enriched):
    """Generate a self-contained HTML report."""

    sev_labels = {1: "Critical", 2: "High", 3: "Medium", 4: "Low"}

    # ── Severity badge rows ──
    severity_rows = ""
    for sev in sorted(suricata_stats.get("severity", {}).keys()):
        count = suricata_stats["severity"][sev]
        label = sev_labels.get(sev, f"Sev {sev}")
        color = {1: "#ef4444", 2: "#f97316", 3: "#eab308", 4: "#3b82f6"}.get(sev, "#6b7280")
        severity_rows += f"""
        <div class="stat-card" style="border-left: 4px solid {color}">
            <div class="stat-value">{count}</div>
            <div class="stat-label">{label}</div>
        </div>"""

    # ── Signature table ──
    sig_rows = ""
    for sig, count in suricata_stats.get("top_signatures", []):
        sig_rows += f"<tr><td>{_esc(sig)}</td><td class='num'>{count}</td></tr>"

    # ── Category table ──
    cat_rows = ""
    for cat, count in suricata_stats.get("categories", {}).items():
        cat_rows += f"<tr><td>{_esc(cat)}</td><td class='num'>{count}</td></tr>"

    # ── IP tables ──
    src_rows = "".join(f"<tr><td><code>{ip}</code></td><td class='num'>{c}</td></tr>"
                       for ip, c in suricata_stats.get("top_src_ips", []))
    dst_rows = "".join(f"<tr><td><code>{ip}</code></td><td class='num'>{c}</td></tr>"
                       for ip, c in suricata_stats.get("top_dst_ips", []))

    # ── Zeek DNS table ──
    dns_rows = "".join(f"<tr><td><code>{q}</code></td><td class='num'>{c}</td></tr>"
                       for q, c in zeek_stats.get("top_dns", []))

    # ── YARA results ──
    yara_match_count = len(yara_results.get("matches", []))
    yara_rows = ""
    for m in yara_results.get("matches", [])[:20]:
        yara_rows += f"""<tr>
            <td><code>{_esc(m.get('rule', ''))}</code></td>
            <td>{_esc(m.get('namespace', ''))}</td>
            <td>{len(m.get('strings', []))}</td>
        </tr>"""

    # ── IOC summary ──
    ioc_data = iocs if isinstance(iocs, dict) else {}
    ioc_ips = ioc_data.get("ips", [])
    ioc_domains = ioc_data.get("domains", [])
    ioc_hashes = ioc_data.get("hashes", [])

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NAPX-Pro Analysis Report</title>
<style>
:root {{
    --bg: #0f1117;
    --surface: #1a1d27;
    --surface2: #232733;
    --border: #2d3348;
    --text: #e2e8f0;
    --text-dim: #94a3b8;
    --accent: #60a5fa;
    --red: #ef4444;
    --orange: #f97316;
    --yellow: #eab308;
    --green: #22c55e;
}}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
    font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
    background: var(--bg);
    color: var(--text);
    line-height: 1.6;
    padding: 2rem;
}}
.container {{ max-width: 1200px; margin: 0 auto; }}
h1 {{
    font-size: 1.8rem;
    margin-bottom: 0.25rem;
    color: var(--accent);
    letter-spacing: -0.02em;
}}
.subtitle {{ color: var(--text-dim); margin-bottom: 2rem; font-size: 0.85rem; }}
h2 {{
    font-size: 1.1rem;
    color: var(--accent);
    margin: 2rem 0 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid var(--border);
}}
.stats-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}}
.stat-card {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1rem;
}}
.stat-value {{ font-size: 1.6rem; font-weight: 700; }}
.stat-label {{ font-size: 0.75rem; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.05em; }}
table {{
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 1.5rem;
    font-size: 0.85rem;
}}
th {{
    text-align: left;
    padding: 0.5rem 0.75rem;
    background: var(--surface);
    border-bottom: 2px solid var(--border);
    font-weight: 600;
    color: var(--text-dim);
    text-transform: uppercase;
    font-size: 0.7rem;
    letter-spacing: 0.05em;
}}
td {{
    padding: 0.4rem 0.75rem;
    border-bottom: 1px solid var(--border);
}}
.num {{ text-align: right; font-variant-numeric: tabular-nums; }}
tr:hover {{ background: var(--surface2); }}
code {{ color: var(--accent); font-size: 0.85em; }}
.two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }}
.badge {{
    display: inline-block;
    padding: 0.15rem 0.5rem;
    border-radius: 4px;
    font-size: 0.7rem;
    font-weight: 600;
}}
.badge-red {{ background: rgba(239,68,68,0.15); color: var(--red); }}
.badge-green {{ background: rgba(34,197,94,0.15); color: var(--green); }}
.footer {{
    margin-top: 3rem;
    padding-top: 1rem;
    border-top: 1px solid var(--border);
    color: var(--text-dim);
    font-size: 0.75rem;
}}
@media (max-width: 768px) {{
    .two-col {{ grid-template-columns: 1fr; }}
    body {{ padding: 1rem; }}
}}
</style>
</head>
<body>
<div class="container">

<h1>NAPX-Pro Analysis Report</h1>
<div class="subtitle">Generated {now}</div>

<!-- Overview Stats -->
<h2>Pipeline Overview</h2>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value">{suricata_stats.get('total_events', 0):,}</div>
        <div class="stat-label">Suricata Events</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{suricata_stats.get('total_alerts', 0):,}</div>
        <div class="stat-label">Alerts</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{zeek_stats.get('connections', 0):,}</div>
        <div class="stat-label">Connections</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{zeek_stats.get('dns_queries_total', 0):,}</div>
        <div class="stat-label">DNS Queries</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{zeek_stats.get('http_requests', 0):,}</div>
        <div class="stat-label">HTTP Requests</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{yara_match_count}</div>
        <div class="stat-label">YARA Matches</div>
    </div>
</div>

<!-- Severity Breakdown -->
<h2>Alert Severity</h2>
<div class="stats-grid">
    {severity_rows}
</div>

<!-- Top Signatures -->
<h2>Top Suricata Signatures</h2>
<table>
    <thead><tr><th>Signature</th><th style="text-align:right">Count</th></tr></thead>
    <tbody>{sig_rows if sig_rows else '<tr><td colspan="2">No alerts</td></tr>'}</tbody>
</table>

<!-- Categories -->
<h2>Alert Categories</h2>
<table>
    <thead><tr><th>Category</th><th style="text-align:right">Count</th></tr></thead>
    <tbody>{cat_rows if cat_rows else '<tr><td colspan="2">No data</td></tr>'}</tbody>
</table>

<!-- IP Analysis -->
<h2>Top Talkers</h2>
<div class="two-col">
    <div>
        <h3 style="font-size:0.85rem; color:var(--text-dim); margin-bottom:0.5rem">Source IPs</h3>
        <table>
            <thead><tr><th>IP</th><th style="text-align:right">Alerts</th></tr></thead>
            <tbody>{src_rows if src_rows else '<tr><td colspan="2">No data</td></tr>'}</tbody>
        </table>
    </div>
    <div>
        <h3 style="font-size:0.85rem; color:var(--text-dim); margin-bottom:0.5rem">Destination IPs</h3>
        <table>
            <thead><tr><th>IP</th><th style="text-align:right">Alerts</th></tr></thead>
            <tbody>{dst_rows if dst_rows else '<tr><td colspan="2">No data</td></tr>'}</tbody>
        </table>
    </div>
</div>

<!-- DNS -->
<h2>Top DNS Queries (Zeek)</h2>
<table>
    <thead><tr><th>Query</th><th style="text-align:right">Count</th></tr></thead>
    <tbody>{dns_rows if dns_rows else '<tr><td colspan="2">No DNS data</td></tr>'}</tbody>
</table>

<!-- Zeek Protocol Breakdown -->
<h2>Protocol Distribution (Zeek)</h2>
<div class="stats-grid">
    {"".join(f'<div class="stat-card"><div class="stat-value">{c:,}</div><div class="stat-label">{p}</div></div>' for p, c in zeek_stats.get("protocols", {}).items())}
</div>

<!-- YARA -->
<h2>YARA Scan Results</h2>
{"<span class='badge badge-green'>CLEAN</span> No YARA matches" if yara_match_count == 0 else f"<span class='badge badge-red'>{yara_match_count} MATCH(ES)</span>"}
{f'''<table>
    <thead><tr><th>Rule</th><th>Namespace</th><th>String Hits</th></tr></thead>
    <tbody>{yara_rows}</tbody>
</table>''' if yara_match_count > 0 else ''}

<!-- IOC Summary -->
<h2>Extracted IOCs</h2>
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value">{len(ioc_ips)}</div>
        <div class="stat-label">Unique IPs</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{len(ioc_domains)}</div>
        <div class="stat-label">Domains</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{len(ioc_hashes)}</div>
        <div class="stat-label">File Hashes</div>
    </div>
</div>

<div class="footer">
    NAPX-Pro &mdash; Network Analysis Pipeline, Extended<br>
    Report auto-generated from Suricata, Zeek, and YARA outputs
</div>

</div>
</body>
</html>"""
    return html


def _esc(s):
    """Minimal HTML escape."""
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def main():
    print("[+] Loading Suricata events...")
    eve_events = load_eve_json(os.path.join(LOG_DIR, "suricata", "eve.json"))
    suricata_stats = analyse_suricata(eve_events)

    print("[+] Loading Zeek logs...")
    zeek_stats = analyse_zeek(os.path.join(LOG_DIR, "zeek"))

    print("[+] Loading YARA results...")
    yara_results = load_json_safe(os.path.join(LOG_DIR, "yara", "results.json"))

    print("[+] Loading IOCs...")
    iocs = load_json_safe(os.path.join(LOG_DIR, "iocs", "iocs.json"))
    enriched = load_json_safe(os.path.join(LOG_DIR, "iocs", "enriched.json"))

    print("[+] Generating HTML report...")
    html = generate_html(suricata_stats, zeek_stats, yara_results, iocs, enriched)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    report_path = os.path.join(OUTPUT_DIR, "report.html")
    with open(report_path, 'w') as f:
        f.write(html)

    # Also dump raw JSON summary
    summary = {
        "suricata": suricata_stats,
        "zeek": zeek_stats,
        "yara_matches": len(yara_results.get("matches", [])),
        "iocs": {
            "ips": len(iocs.get("ips", [])),
            "domains": len(iocs.get("domains", [])),
            "hashes": len(iocs.get("hashes", []))
        }
    }
    with open(os.path.join(OUTPUT_DIR, "summary.json"), 'w') as f:
        json.dump(summary, f, indent=2, default=str)

    print(f"[+] Report written to {report_path}")


if __name__ == "__main__":
    main()
