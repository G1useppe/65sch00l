#!/usr/bin/env bash
set -euo pipefail

############################################
# NAPX-Pro Orchestrator
# Coordinates: PCAP copy → metadata → replay signal → enrichment
############################################

INTERFACE="${INTERFACE:-lo}"
REPLAY_SPEED="${REPLAY_SPEED:-1.0}"
ENRICHMENT_ENABLED="${ENRICHMENT_ENABLED:-false}"

echo "============================================"
echo "  NAPX-Pro Orchestrator"
echo "  Interface: $INTERFACE"
echo "  Replay speed: ${REPLAY_SPEED}x"
echo "============================================"

# ── Step 1: Copy PCAP into shared volume ──────────────────────────────
echo "[+] Stage 1: Preparing PCAP"

PCAP_SRC=$(find /input -name '*.pcap' -o -name '*.pcapng' | head -n 1)

if [[ -z "$PCAP_SRC" ]]; then
    echo "[!] No PCAP found in /input/"
    echo "    Mount a PCAP file to ./input/ and restart"
    exit 1
fi

cp "$PCAP_SRC" /pcap/demo.pcap
echo "[+] PCAP loaded: $(basename "$PCAP_SRC")"

# ── Step 2: Metadata extraction ──────────────────────────────────────
echo "[+] Stage 2: Extracting metadata"

mkdir -p /logs/metadata

if command -v capinfos &>/dev/null; then
    capinfos -A /pcap/demo.pcap > /logs/metadata/capinfos.txt 2>&1 || true
fi

# Basic stats via tcpdump
tcpdump -r /pcap/demo.pcap -qn 2>/dev/null | tail -1 > /logs/metadata/summary.txt || true

PACKET_COUNT=$(tcpdump -r /pcap/demo.pcap -qn 2>/dev/null | wc -l || echo "unknown")
echo "[+] Packet count: $PACKET_COUNT"

# ── Step 3: Signal sensors to start ──────────────────────────────────
echo "[+] Stage 3: Signalling sensors"
touch /pcap/.replay_started

# Give sensors a moment to initialise
sleep 3

# ── Step 4: Wait for analysis to complete ─────────────────────────────
echo "[+] Stage 4: Waiting for Suricata and Zeek"

TIMEOUT=300
ELAPSED=0
while [[ $ELAPSED -lt $TIMEOUT ]]; do
    SURI_DONE=false
    ZEEK_DONE=false
    [[ -f /logs/suricata/.suricata_done ]] && SURI_DONE=true
    [[ -f /logs/zeek/.zeek_done ]] && ZEEK_DONE=true

    if $SURI_DONE && $ZEEK_DONE; then
        echo "[+] All sensors complete"
        break
    fi

    sleep 2
    ELAPSED=$((ELAPSED + 2))
done

if [[ $ELAPSED -ge $TIMEOUT ]]; then
    echo "[!] Timeout waiting for sensors (${TIMEOUT}s)"
fi

# ── Step 5: IOC Extraction ────────────────────────────────────────────
echo "[+] Stage 5: Extracting IOCs"

mkdir -p /logs/iocs

python3 /scripts/extract_iocs.py \
    --eve /logs/suricata/eve.json \
    --zeek-dir /logs/zeek \
    --output /logs/iocs/iocs.json \
    2>/dev/null || echo "[!] IOC extraction had warnings"

# ── Step 6: Threat Intel Enrichment (optional) ────────────────────────
if [[ "$ENRICHMENT_ENABLED" == "true" ]]; then
    echo "[+] Stage 6: Enriching IOCs with threat intelligence"

    python3 /scripts/enrich_iocs.py \
        --input /logs/iocs/iocs.json \
        --output /logs/iocs/enriched.json \
        --vt-key "${VT_API_KEY:-}" \
        --abuseipdb-key "${ABUSEIPDB_KEY:-}" \
        2>/dev/null || echo "[!] Enrichment had warnings"
else
    echo "[+] Stage 6: Enrichment disabled (set NAPX_ENRICHMENT=true to enable)"
fi

# ── Done ──────────────────────────────────────────────────────────────
echo
echo "============================================"
echo "  NAPX-Pro Pipeline Complete"
echo "============================================"
echo "  Kibana:  http://localhost:5601"
echo "  ES API:  http://localhost:9200"
echo "============================================"
echo
echo "  Artifacts in ./output/ after report generation"
echo "============================================"

# Keep container alive for debugging
tail -f /dev/null
