/*
    NAPX-Pro Sample YARA Rules
    Add your own rules to this directory (.yar or .yara extension)
*/

rule Suspicious_PE_In_PCAP
{
    meta:
        description = "Detects PE executable transferred in network capture"
        author = "NAPX-Pro"
        severity = "high"

    strings:
        $mz = { 4D 5A }
        $pe = "PE\x00\x00"
        $dos_msg = "This program cannot be run in DOS mode"

    condition:
        $mz and ($pe or $dos_msg)
}

rule Suspicious_PowerShell_Download
{
    meta:
        description = "PowerShell download cradle in network traffic"
        author = "NAPX-Pro"
        severity = "high"

    strings:
        $ps1 = "IEX" ascii nocase
        $ps2 = "Invoke-Expression" ascii nocase
        $ps3 = "DownloadString" ascii nocase
        $ps4 = "Net.WebClient" ascii nocase
        $ps5 = "Invoke-WebRequest" ascii nocase
        $ps6 = "Start-BitsTransfer" ascii nocase

    condition:
        any of ($ps1, $ps2) and any of ($ps3, $ps4, $ps5, $ps6)
}

rule Base64_Encoded_Executable
{
    meta:
        description = "Base64-encoded PE header in traffic"
        author = "NAPX-Pro"
        severity = "medium"

    strings:
        $b64_mz_1 = "TVqQAAMAAAA" ascii
        $b64_mz_2 = "TVpQAAIAAAA" ascii
        $b64_mz_3 = "TVoAAAAAAAA" ascii

    condition:
        any of them
}

rule Cobalt_Strike_Beacon_Indicators
{
    meta:
        description = "Common Cobalt Strike beacon patterns"
        author = "NAPX-Pro"
        severity = "critical"

    strings:
        $pipe1 = "\\\\.\\pipe\\msagent_" ascii
        $pipe2 = "\\\\.\\pipe\\MSSE-" ascii
        $uri1 = "/submit.php?" ascii
        $uri2 = "/activity" ascii
        $ua = "Mozilla/5.0 (compatible; MSIE" ascii
        $cfg = { 00 01 00 01 00 02 ?? ?? 00 02 00 01 00 02 ?? ?? }

    condition:
        2 of them
}

rule Suspicious_Shell_Commands
{
    meta:
        description = "Common reverse shell / post-exploitation commands"
        author = "NAPX-Pro"
        severity = "high"

    strings:
        $sh1 = "/bin/sh -i" ascii
        $sh2 = "/bin/bash -i" ascii
        $sh3 = "bash -c 'bash -i" ascii
        $nc1 = "nc -e /bin" ascii
        $nc2 = "ncat -e /bin" ascii
        $py1 = "import socket,subprocess" ascii
        $py2 = "import pty;pty.spawn" ascii

    condition:
        any of them
}
