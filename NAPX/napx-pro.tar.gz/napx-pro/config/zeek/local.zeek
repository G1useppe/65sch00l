# NAPX-Pro Zeek Configuration
# Enables community_id for Suricata correlation and file extraction

@load base/protocols/conn
@load base/protocols/dns
@load base/protocols/http
@load base/protocols/ssl
@load base/protocols/ftp
@load base/protocols/smtp
@load base/files/extract
@load base/frameworks/files

# Community ID for cross-tool correlation with Suricata
@load policy/protocols/conn/community-id-logging

# Detect and log software versions
@load policy/protocols/http/detect-webapps
@load policy/protocols/http/software
@load policy/protocols/ssl/validate-certs

# Hash all files seen on the wire
@load policy/frameworks/files/hash-all-files

# Extract files (capped at 10MB each)
@load policy/frameworks/files/extract-all-files

redef FileExtract::prefix = "/zeek_logs/extracted_files/";

# Log in JSON format for easier ELK ingestion
redef LogAscii::use_json = T;
