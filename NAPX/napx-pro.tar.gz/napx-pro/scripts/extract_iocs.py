#!/usr/bin/env python3
"""
NAPX-Pro IOC Extractor
Pulls IPs, domains, hashes from Suricata eve.json and Zeek logs.
"""

import json
import os
import re
import argparse
from collections import defaultdict

# RFC1918 / link-local / loopback — skip these
PRIVATE_NETS = re.compile(
    r'^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|127\.|169\.254\.|0\.)'
)


def extract_from_eve(eve_path):
    """Extract IOCs from Suricata eve.json."""
    ips = set()
    domains = set()
    hashes = set()

    if not os.path.isfile(eve_path):
        return ips, domains, hashes

    with open(eve_path) as f:
        for line in f:
            try:
                ev = json.loads(line.strip())
            except (json.JSONDecodeError, ValueError):
                continue

            for key in ('src_ip', 'dest_ip'):
                ip = ev.get(key, '')
                if ip and not PRIVATE_NETS.match(ip):
                    ips.add(ip)

            # DNS answers in eve
            dns = ev.get('dns', {})
            if isinstance(dns, dict):
                q = dns.get('rrname', '')
                if q:
                    domains.add(q)

            # Fileinfo hashes
            fi = ev.get('fileinfo', {})
            if isinstance(fi, dict):
                for h in ('sha256', 'sha1', 'md5'):
                    val = fi.get(h, '')
                    if val:
                        hashes.add(val)

    return ips, domains, hashes


def extract_from_zeek(zeek_dir):
    """Extract IOCs from Zeek conn.log, dns.log, files.log."""
    ips = set()
    domains = set()
    hashes = set()

    # conn.log → IPs
    conn_path = os.path.join(zeek_dir, 'conn.log')
    if os.path.isfile(conn_path):
        headers = []
        with open(conn_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#fields'):
                    headers = line.split('\t')[1:]
                elif line.startswith('#'):
                    continue
                elif headers:
                    vals = dict(zip(headers, line.split('\t')))
                    for key in ('id.orig_h', 'id.resp_h'):
                        ip = vals.get(key, '')
                        if ip and not PRIVATE_NETS.match(ip):
                            ips.add(ip)

    # dns.log → domains
    dns_path = os.path.join(zeek_dir, 'dns.log')
    if os.path.isfile(dns_path):
        headers = []
        with open(dns_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#fields'):
                    headers = line.split('\t')[1:]
                elif line.startswith('#'):
                    continue
                elif headers:
                    vals = dict(zip(headers, line.split('\t')))
                    q = vals.get('query', '')
                    if q and q != '-':
                        domains.add(q)

    # files.log → hashes
    files_path = os.path.join(zeek_dir, 'files.log')
    if os.path.isfile(files_path):
        headers = []
        with open(files_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('#fields'):
                    headers = line.split('\t')[1:]
                elif line.startswith('#'):
                    continue
                elif headers:
                    vals = dict(zip(headers, line.split('\t')))
                    for h in ('sha256', 'sha1', 'md5'):
                        val = vals.get(h, '')
                        if val and val != '-':
                            hashes.add(val)

    return ips, domains, hashes


def main():
    parser = argparse.ArgumentParser(description="Extract IOCs from NAPX logs")
    parser.add_argument('--eve', default='/logs/suricata/eve.json')
    parser.add_argument('--zeek-dir', default='/logs/zeek')
    parser.add_argument('--output', default='/logs/iocs/iocs.json')
    args = parser.parse_args()

    eve_ips, eve_domains, eve_hashes = extract_from_eve(args.eve)
    zeek_ips, zeek_domains, zeek_hashes = extract_from_zeek(args.zeek_dir)

    all_ips = sorted(eve_ips | zeek_ips)
    all_domains = sorted(eve_domains | zeek_domains)
    all_hashes = sorted(eve_hashes | zeek_hashes)

    result = {
        "extracted_at": __import__('datetime').datetime.now(
            __import__('datetime').timezone.utc
        ).isoformat(),
        "ips": all_ips,
        "domains": all_domains,
        "hashes": all_hashes,
        "counts": {
            "ips": len(all_ips),
            "domains": len(all_domains),
            "hashes": len(all_hashes),
        }
    }

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, 'w') as f:
        json.dump(result, f, indent=2)

    print(f"[+] IOCs extracted: {len(all_ips)} IPs, {len(all_domains)} domains, {len(all_hashes)} hashes")


if __name__ == "__main__":
    main()
