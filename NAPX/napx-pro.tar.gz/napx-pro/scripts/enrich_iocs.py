#!/usr/bin/env python3
"""
NAPX-Pro IOC Enrichment
Queries VirusTotal and AbuseIPDB for extracted IOCs.
Respects API rate limits with built-in throttling.
"""

import json
import os
import time
import argparse

try:
    import requests
except ImportError:
    requests = None


def enrich_ip_virustotal(ip, api_key):
    """Query VT for IP reputation."""
    if not api_key or not requests:
        return None
    try:
        r = requests.get(
            f"https://www.virustotal.com/api/v3/ip_addresses/{ip}",
            headers={"x-apikey": api_key},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json().get("data", {}).get("attributes", {})
            stats = data.get("last_analysis_stats", {})
            return {
                "malicious": stats.get("malicious", 0),
                "suspicious": stats.get("suspicious", 0),
                "harmless": stats.get("harmless", 0),
                "reputation": data.get("reputation", 0),
                "country": data.get("country", ""),
                "as_owner": data.get("as_owner", ""),
            }
    except Exception as e:
        print(f"  [!] VT error for {ip}: {e}")
    return None


def enrich_ip_abuseipdb(ip, api_key):
    """Query AbuseIPDB for IP reputation."""
    if not api_key or not requests:
        return None
    try:
        r = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": api_key, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": 90},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json().get("data", {})
            return {
                "abuse_confidence": data.get("abuseConfidenceScore", 0),
                "total_reports": data.get("totalReports", 0),
                "country": data.get("countryCode", ""),
                "isp": data.get("isp", ""),
                "usage_type": data.get("usageType", ""),
            }
    except Exception as e:
        print(f"  [!] AbuseIPDB error for {ip}: {e}")
    return None


def enrich_hash_virustotal(file_hash, api_key):
    """Query VT for file hash reputation."""
    if not api_key or not requests:
        return None
    try:
        r = requests.get(
            f"https://www.virustotal.com/api/v3/files/{file_hash}",
            headers={"x-apikey": api_key},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json().get("data", {}).get("attributes", {})
            stats = data.get("last_analysis_stats", {})
            return {
                "malicious": stats.get("malicious", 0),
                "suspicious": stats.get("suspicious", 0),
                "harmless": stats.get("harmless", 0),
                "type_description": data.get("type_description", ""),
                "meaningful_name": data.get("meaningful_name", ""),
            }
    except Exception as e:
        print(f"  [!] VT error for hash {file_hash[:16]}...: {e}")
    return None


def main():
    parser = argparse.ArgumentParser(description="Enrich IOCs with threat intel")
    parser.add_argument('--input', default='/logs/iocs/iocs.json')
    parser.add_argument('--output', default='/logs/iocs/enriched.json')
    parser.add_argument('--vt-key', default='')
    parser.add_argument('--abuseipdb-key', default='')
    parser.add_argument('--max-ips', type=int, default=50, help="Max IPs to enrich")
    parser.add_argument('--max-hashes', type=int, default=20, help="Max hashes to enrich")
    args = parser.parse_args()

    if not requests:
        print("[!] 'requests' library not available, skipping enrichment")
        return

    with open(args.input) as f:
        iocs = json.load(f)

    enriched = {"ips": {}, "hashes": {}, "domains": iocs.get("domains", [])}

    # Enrich IPs (throttled)
    ips = iocs.get("ips", [])[:args.max_ips]
    print(f"[+] Enriching {len(ips)} IPs...")

    for i, ip in enumerate(ips):
        print(f"  [{i+1}/{len(ips)}] {ip}")
        entry = {"ip": ip}

        if args.vt_key:
            entry["virustotal"] = enrich_ip_virustotal(ip, args.vt_key)
            time.sleep(15)  # VT free tier: 4 req/min

        if args.abuseipdb_key:
            entry["abuseipdb"] = enrich_ip_abuseipdb(ip, args.abuseipdb_key)
            time.sleep(1)

        enriched["ips"][ip] = entry

    # Enrich hashes
    hashes = iocs.get("hashes", [])[:args.max_hashes]
    print(f"[+] Enriching {len(hashes)} hashes...")

    for i, h in enumerate(hashes):
        print(f"  [{i+1}/{len(hashes)}] {h[:32]}...")
        entry = {"hash": h}

        if args.vt_key:
            entry["virustotal"] = enrich_hash_virustotal(h, args.vt_key)
            time.sleep(15)

        enriched["hashes"][h] = entry

    # Score summary
    flagged_ips = sum(
        1 for v in enriched["ips"].values()
        if (v.get("virustotal", {}) or {}).get("malicious", 0) > 0
        or (v.get("abuseipdb", {}) or {}).get("abuse_confidence", 0) > 50
    )

    enriched["summary"] = {
        "total_ips_checked": len(ips),
        "flagged_ips": flagged_ips,
        "total_hashes_checked": len(hashes),
    }

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, 'w') as f:
        json.dump(enriched, f, indent=2)

    print(f"[+] Enrichment complete: {flagged_ips} flagged IPs out of {len(ips)}")


if __name__ == "__main__":
    main()
